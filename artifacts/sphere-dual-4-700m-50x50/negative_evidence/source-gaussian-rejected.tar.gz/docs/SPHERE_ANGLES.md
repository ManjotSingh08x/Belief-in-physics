# Joint Sphere angle tokens

The 180-run polar campaign observed only theta. Its 181-token checkpoints and
published heatmaps cannot represent absolute azimuth or demonstrate convergence
of full spatial trajectories. They remain evidence about a partial observation.

Use the same physical dynamics with both angles:

```python
from physics.messk import MessDriven
from physics.systems.sphere_angles import SphereAngles

proc = MessDriven(system=SphereAngles(), obs_bins=(181, 181),
                  dt=0.04, integration_dt=0.005, delta_v=0.12)
tokens = proc.observe(states)  # states[..., :] = theta, psi, dtheta, dpsi
angles = proc.undiscretise(tokens)
```

All angles are radians. Theta covers [0, pi], rather than clipping to the old
empirical [0.05, 1.25] observation band. Azimuth is circular with 181 distinct
bin centers in [-pi, pi); -pi and +pi name the same center. The formulas are:

```
i_theta = clip(rint(theta / pi * 180), 0, 180)
i_psi   = floor(((psi + pi) mod (2*pi)) / (2*pi) * 181 + 0.5) mod 181
token   = i_theta * 181 + i_psi
```

Vocabulary size is 32,761; one token encodes one pair of angle bins, not a mood.
Quantization error is at most 0.5 degrees in theta and 180/181 degrees in azimuth.
The system requires two bin counts so a scalar default fails clearly.
Sampling accepts explicit randomized initial states through the existing
`sample_batch(..., initial_state=...)` argument. Velocities still require inference
from observation history: these are position tokens, not full phase-space tokens.

Build new models with `vocab_size=proc.n_obs`. The old weights are incompatible;
new training, grouped held-out probes, calibration, and randomized-start tests
are required before making claims about learned joint predictions. No new
training or rental has been launched for this change.

Check: `PYTHONPATH=. python tests/check_sphere_angles.py`.
