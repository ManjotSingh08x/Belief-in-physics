"""Exactly four screened 50x50 Sphere recipes; reuse the campaign training loop."""
from __future__ import annotations

import argparse
from dataclasses import dataclass, replace
import hashlib
import json
import os
import time
from pathlib import Path
from typing import ClassVar

from experiments.sphere_dual_screen import starts
from experiments.sphere_vast_train import configuration_sha256, recipe, run_name, scope, train_run
from physics.systems.sphere_angles import SphereAngles


def runs(screen_path, output, device="cpu"):
    screened = json.loads(screen_path.read_text())
    if screened["status"] != "four_selected" or len(screened["selected"]) != 4:
        raise ValueError("exactly four independently screened settings required")
    if not all(row.get("additional_seed_pass") and len(row.get("additional_seeds", [])) == 10
               for row in screened["selected"]):
        raise ValueError("the ten additional seed checks must pass before training")
    root = Path(__file__).resolve().parents[1]
    for path, expected in screened["source_sha256"].items():
        if not path.startswith("physics/"):
            continue  # Screen versions remain in the evidence; training uses the verified physics.
        if hashlib.sha256((root / path).read_bytes()).hexdigest() != expected:
            raise ValueError(f"screened source changed: {path}")
    ns = scope("half", output, device)

    @dataclass(frozen=True)
    class DualSphereConfig(ns["PolarSphereConfig"]):
        system_name: ClassVar[str] = "sphere_dual"
        obs_bins: tuple[int, int] = (50, 50)

        def build_system(self):
            self.validate()
            return SphereAngles(g=self.g, length=self.length, gamma=self.gamma, rate_max=self.rate_max)

    @dataclass(frozen=True)
    class DualInitialStateConfig(ns["InitialStateConfig"]):
        mode: str = "random"
        azimuth_mode: str = "uniform [-pi,pi)"

        def sample(self, system, rng, batch_size):
            self.validate()
            if self.mode != "random" or self.jitter_std != .1:
                raise ValueError("use the screened sigma .1 randomized release")
            return starts(system, rng, batch_size)

    base = ns["ACTIVE_RUNS"][0]
    selected = []
    for index, row in enumerate(screened["selected"]):
        c = row["config"]
        if not row["pass"] or row["reference"]["min_joint_token_agreement"] < .999:
            raise ValueError("unsafe screened setting")
        exp = replace(base[0], name=f"sphere_dual50_c{index}_n{c['n']}_g{c['gamma']}_dv{c['delta_v']}_a{c['alpha']}",
                      physics=DualSphereConfig(gamma=c["gamma"], delta_v=c["delta_v"]),
                      hmm=ns["HMMConfig"](alpha=c["alpha"], stay=.7),
                      initial_state=DualInitialStateConfig(), m=500 // c["n"], n=c["n"])
        tr = replace(base[1], name="d128l4h2mlp512_700m_seed0_k10", k=10)
        proc = exp.build_process()
        assert proc.n_obs == 2500 and proc.obs_bins == (50, 50) and proc.seq_len == 500
        selected.append((exp, tr))
    ns["ACTIVE_RUNS"] = selected
    return ns, selected


def plan(args):
    ns, selected = runs(args.screen, args.output.parent)
    jobs = []
    for index, (exp, tr) in enumerate(selected):
        proc = exp.build_process()
        jobs.append({"index": index, "name": run_name(exp, tr), "recipe": recipe(exp, tr, proc),
                     "configuration_sha256": configuration_sha256(exp, tr, proc),
                     "actual_tokens": tr.total_tokens // (tr.batch_size * proc.seq_len) * tr.batch_size * proc.seq_len})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({"hypothesis_id": "H-SPHERE-JOINT-50", "total": 4,
        "max_total_dollars": 5., "training_seed": 0, "screen_sha256": hashlib.sha256(args.screen.read_bytes()).hexdigest(),
        "jobs": jobs, "acceptance_state": "screened; untrained"}, indent=2) + '\n')


def train_one(args):
    if not 0 <= args.index < 4:
        raise ValueError("only indices 0 through 3 are authorized")
    ns, selected = runs(args.screen, args.output, args.device)
    exp, tr = selected[args.index]
    train_run(ns, exp, tr, args, hypothesis_id="H-SPHERE-JOINT-50",
              dataset="fresh streamed Mess-4 joint-angle Sphere; sigma .1 releases, uniform azimuth; 500 tokens")


def benchmark(args):
    import numpy as np
    import torch
    torch.set_num_threads(2)
    ns, selected = runs(args.screen, args.output, 'cuda')
    exp, tr = selected[args.index]
    p = exp.build_process()
    model = tr.build_model(p).to('cuda')
    rng = np.random.default_rng(9000 + args.index)
    def sample(size):
        return torch.as_tensor(exp.sample_batch(p, rng, size)['tokens'], dtype=torch.long, device='cuda')
    with torch.no_grad():
        eval_loss = float(model.loss(sample(tr.eval_size)))
    torch.cuda.synchronize()
    start = time.monotonic()
    losses = []
    for _ in range(5):
        model.zero_grad(set_to_none=True)
        loss = model.loss(sample(args.micro_batch))
        loss.backward()
        losses.append(float(loss.detach()))
    torch.cuda.synchronize()
    elapsed = time.monotonic() - start
    if not np.isfinite([eval_loss, *losses]).all():
        raise RuntimeError('nonfinite preflight loss')
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / f'benchmark_{args.index}.json').write_text(json.dumps({
        'index': args.index, 'optimizer_updates': 0, 'finite_losses': losses,
        'eval_loss': eval_loss, 'tokens_per_second': 5 * args.micro_batch * p.seq_len / elapsed,
        'elapsed_seconds': elapsed, 'gpu': torch.cuda.get_device_name(0),
        'peak_cuda_bytes': torch.cuda.max_memory_allocated(),
        'configuration_sha256': configuration_sha256(exp, tr, p)}, indent=2) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    for name in ('plan', 'train', 'benchmark'):
        p = sub.add_parser(name)
        p.add_argument('--screen', type=Path, required=True)
        p.add_argument('--output', type=Path, required=True)
        if name in ('train', 'benchmark'):
            p.add_argument('--index', type=int, required=True)
            p.add_argument('--device', default='cuda')
            p.add_argument('--micro-batch', type=int, default=32)
    args = parser.parse_args()
    {'plan': plan, 'train': train_one, 'benchmark': benchmark}[args.command](args)
