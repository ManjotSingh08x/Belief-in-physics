"""One four-worker GPU launch, gated by no-update throughput and the hard deadline."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def main(args):
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'TRAIN_PIDS.json').exists():
        raise RuntimeError('training already launched')
    plan = json.loads(args.plan.read_text())
    assert plan['total'] == 4 and len(plan['jobs']) == 4 and plan['max_total_dollars'] == 5
    env = dict(os.environ, OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='1',
               BELIEF_SOURCE_REVISION=args.revision)
    active = []
    def start(command, index):
        log = (out / f'{command}_{index}.log').open('a')
        p = subprocess.Popen([sys.executable, '-m', 'experiments.sphere_dual_four', command,
                              '--screen', str(args.screen), '--output', str(out), '--index', str(index),
                              '--micro-batch', '32'], env=env, stdout=log, stderr=log, start_new_session=True)
        active.append((p, log))
        return p
    old = signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    try:
        bench = [start('benchmark', i) for i in range(4)]
        for p in bench:
            if p.wait(timeout=600):
                raise RuntimeError('GPU preflight failed')
        for _, log in active:
            log.close()
        active.clear()
        metrics = [json.loads((out / f'benchmark_{i}.json').read_text()) for i in range(4)]
        for i, m in enumerate(metrics):
            assert m['configuration_sha256'] == plan['jobs'][i]['configuration_sha256'] and m['optimizer_updates'] == 0
        tps = min(m['tokens_per_second'] for m in metrics) * 4
        remaining = args.deadline - 600 - time.time()
        projected_seconds = sum(job['actual_tokens'] for job in plan['jobs']) / tps * 1.5 + 600
        accepted = projected_seconds < remaining
        (out / 'benchmark_aggregate.json').write_text(json.dumps({
            'accepted': accepted, 'conservative_aggregate_tokens_per_second': tps,
            'projected_seconds_with_50percent_margin': projected_seconds,
            'remaining_seconds_before_stop': remaining, 'workers': metrics}, indent=2) + '\n')
        if not accepted:
            raise RuntimeError('all four 700M runs do not fit the hard budget')
        workers = [start('train', i) for i in range(4)]
        (out / 'TRAIN_PIDS.json').write_text(json.dumps([p.pid for p in workers]) + '\n')
        while any(p.poll() is None for p in workers):
            if time.time() >= args.deadline - 600:
                raise RuntimeError('hard budget stop')
            if any(p.poll() not in (None, 0) for p in workers):
                raise RuntimeError('a training worker failed')
            time.sleep(5)
        if any(p.returncode for p in workers):
            raise RuntimeError('a training worker failed')
        (out / 'GPU_TRAINING_DONE.json').write_text(json.dumps({'models': 4, 'time': time.time()}) + '\n')
    finally:
        for p, log in active:
            if p.poll() is None:
                os.killpg(p.pid, signal.SIGTERM)
                try:
                    p.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(p.pid, signal.SIGKILL)
                    p.wait()
            log.close()
        signal.signal(signal.SIGTERM, old)


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    for name in ('screen', 'plan', 'output'):
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--deadline', type=float, required=True)
    p.add_argument('--revision', required=True)
    args = p.parse_args()
    try:
        main(args)
    except BaseException as error:
        (args.output / 'GPU_FAILURE.json').write_text(json.dumps({'error': type(error).__name__, 'message': str(error)}) + '\n')
        raise
