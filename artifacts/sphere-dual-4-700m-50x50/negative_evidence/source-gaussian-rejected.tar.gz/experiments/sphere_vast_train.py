"""Plan and train the Sphere sweep; probes run separately on staging-entity."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import signal
import subprocess
import sys
import time
import types
from dataclasses import asdict, dataclass, replace
from pathlib import Path

import numpy as np
import torch


ROOT = Path(__file__).resolve().parents[1]
NOTEBOOK = ROOT / "notebooks/three_phase_pipeline.ipynb"
MODES = ("fixed", "half", "n_plus_one")
POLAR_CANDIDATES = (
    ("base", 10, .35), ("n_up_gamma_down", 20, .175),
    ("n_down_gamma_up", 5, .70), ("n_up_gamma_constant", 20, .35),
    ("n_down_gamma_constant", 5, .35),
)
DELTAS = (.10, .12, .14)


def horizon() -> str:
    value = os.environ.get("BELIEF_SPHERE_HORIZON", "16")
    if value not in ("16", "500"):
        raise ValueError("BELIEF_SPHERE_HORIZON must be 16 or 500")
    return value


def recipe(experiment, training, process) -> dict:
    return {"experiment": experiment.metadata(), "training": asdict(training),
            "model": asdict(training.model_config(process))}


def configuration_sha256(experiment, training, process) -> str:
    return hashlib.sha256(json.dumps(recipe(experiment, training, process), sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def save_weights(model, path: Path) -> str:
    part = path.with_name(path.name + ".part")
    torch.save({key: value.detach().cpu() for key, value in model.state_dict().items()}, part)
    digest = hashlib.sha256(part.read_bytes()).hexdigest()
    os.replace(part, path)
    return digest


def validate_ready(checkpoint: Path, revision: str, digest: str | None = None) -> bool:
    ready, metadata = checkpoint.with_suffix(".ready"), checkpoint.with_suffix(".json")
    if not ready.exists():
        return False
    if not checkpoint.exists() or not metadata.exists():
        raise ValueError(f"incomplete ready checkpoint: {checkpoint}")
    info = json.loads(metadata.read_text())
    random_name = info.get("random_checkpoint_filename")
    random_file = checkpoint.parent / random_name if isinstance(random_name, str) else None
    if (info.get("source_revision") != revision or
            (digest is not None and info.get("configuration_sha256") != digest) or
            info.get("checkpoint_sha256") != ready.read_text().strip() or
            hashlib.sha256(checkpoint.read_bytes()).hexdigest() != info.get("checkpoint_sha256") or
            random_file is None or random_file.name != f"{checkpoint.stem}_random_init.pt" or
            not random_file.exists() or
            hashlib.sha256(random_file.read_bytes()).hexdigest() != info.get("random_checkpoint_sha256")):
        raise ValueError(f"invalid ready checkpoint: {checkpoint}")
    return True


def source_revision() -> str:
    return os.environ.get("BELIEF_SOURCE_REVISION") or subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()


def scope(mode: str, output: Path, device: str = "cpu") -> dict:
    os.environ.update({
        "BELIEF_REPO_ROOT": str(ROOT), "BELIEF_RUN_FULL_SWEEP": "1",
        "BELIEF_SYSTEM_FILTER": "sphere", "BELIEF_SEED_FILTER": "0",
        "BELIEF_K_MODE": mode, "BELIEF_NOTEBOOK_DEVICE": device,
        "BELIEF_NOTEBOOK_OUTPUT_DIR": str(output),
        "BELIEF_RUN_START": "0", "BELIEF_RUN_STOP": "60",
    })
    cell = json.loads(NOTEBOOK.read_text())["cells"][2]
    source = "".join(cell["source"]).replace("%matplotlib inline\n", "", 1)
    module_name = f"_sphere_notebook_{mode}"
    module = types.ModuleType(module_name)
    sys.modules[module_name] = module
    namespace = module.__dict__
    exec(compile(source, str(NOTEBOOK), "exec"), namespace)
    from physics.systems.sphere_polar import SphereBall as PolarSphereBall

    @dataclass(frozen=True)
    class PolarSphereConfig(namespace["SphereConfig"]):
        dt: float = .04
        integration_dt: float = .005
        delta_v: float = .12
        obs_bins: int = 181
        psi_dot0: float = 2.0

        def build_system(self):
            self.validate()
            return PolarSphereBall(g=self.g, length=self.length,
                                   gamma=self.gamma, rate_max=self.rate_max)

    selected_horizon = horizon()
    candidates = [(condition, n, delta, gamma)
                  for condition, n, gamma in POLAR_CANDIDATES for delta in DELTAS]
    candidates.sort(key=lambda candidate: candidate != ("base", 10, .12, .35))
    experiments = []
    for index, (condition, n, delta, gamma) in enumerate(candidates):
        for alpha in (.50, .70, .85, .95):
            experiments.append(namespace["ExperimentConfig"](
                name=f"sphere_polar_c{index:02d}_{condition}_d{str(delta).replace('.', 'p')}_a{str(alpha).replace('.', 'p')}_m{selected_horizon}",
                physics=PolarSphereConfig(delta_v=delta, gamma=gamma),
                hmm=namespace["HMMConfig"](alpha=alpha, stay=.7),
                initial_state=namespace["InitialStateConfig"](mode="fixed"),
                seed=20260920 + index, n_trajectories=256,
                m=16 if selected_horizon == "16" else 500 // n, n=n,
            ))
    runs = []
    for experiment in experiments:
        k = (1 if mode == "fixed" else max(1, experiment.n // 2)
             if mode == "half" else experiment.n + 1)
        training = namespace["TrainingConfig"](
            name=f"d128l4h2mlp512_700m_seed0_k{k}", seed=0, k=k,
            d_model=128, n_layers=4, n_heads=2, d_mlp=512,
            batch_size=1024, total_tokens=700_000_000,
            learning_rate=.001, weight_decay=0., log_every=50,
            stream_seed_offset=101, eval_size=256, grad_clip=1.,
        )
        runs.append((experiment, training))
    runs.sort(key=lambda pair: pair[0].name != f"sphere_polar_c00_base_d0p12_a0p7_m{selected_horizon}")
    namespace["PolarSphereConfig"] = PolarSphereConfig
    namespace["EXPERIMENT_CONFIGS"] = experiments
    namespace["ACTIVE_RUNS"] = runs
    namespace["ACTIVE_EXPERIMENTS"] = experiments
    namespace["EXPERIMENT_CONFIG"] = runs[0][0]
    namespace["sample_physics_batch"] = lambda proc, rng, size, exp_cfg=None: (
        exp_cfg or namespace["EXPERIMENT_CONFIG"]).sample_batch(proc, rng, size)
    assert len(namespace["ACTIVE_RUNS"]) == 60
    return namespace


def run_name(experiment, training) -> str:
    return f"{experiment.name}_{training.name}"


def completed_names(root: Path, revision: str, expected: dict[str, str] | None = None) -> dict[str, str]:
    names = {}
    for checkpoint in root.rglob("*.pth"):
        metadata = checkpoint.with_suffix(".json")
        if not metadata.exists():
            continue
        info = json.loads(metadata.read_text())
        if info.get("source_revision") != revision or (expected is not None and
                info.get("configuration_sha256") != expected.get(checkpoint.stem)):
            continue
        if expected is not None and not validate_ready(checkpoint, revision,
                                                        expected[checkpoint.stem]):
            continue
        if all(checkpoint.with_suffix(ext).exists() for ext in (".csv", ".zip")):
            names[checkpoint.stem] = "probed"
        elif (ready := checkpoint.with_suffix(".ready")).exists():
            if expected is None and hashlib.sha256(checkpoint.read_bytes()).hexdigest() != ready.read_text().strip():
                raise ValueError(f"invalid staged checkpoint: {checkpoint}")
            names[checkpoint.stem] = "checkpoint_ready"
    return names


def plan(args) -> None:
    revision = source_revision()
    entries = []
    for mode in MODES:
        runs = scope(mode, args.output.parent)["ACTIVE_RUNS"]
        for index, (experiment, training) in enumerate(runs):
            name = run_name(experiment, training)
            process = experiment.build_process()
            item = {"mode": mode, "index": index, "name": name,
                    "seed": training.seed, "k": training.k,
                    "experiment": experiment.name,
                    "configuration_sha256": configuration_sha256(experiment, training, process),
                    "recipe": recipe(experiment, training, process)}
            entries.append(item)
    assert len(entries) == 180
    assert len({x["name"] for x in entries}) == 180
    complete = completed_names(args.completed_dir, revision,
                               {x["name"]: x["configuration_sha256"] for x in entries})
    jobs, skipped = [], []
    for item in entries:
        reason = complete.get(item["name"])
        (skipped if reason else jobs).append({**item, **({"reason": reason} if reason else {})})
    assert len(jobs) + len(skipped) == 180
    assert len({x["name"] for x in jobs + skipped}) == 180
    result = {"source_revision": revision, "total": 180,
              "jobs": jobs, "skipped": skipped}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    counts = {reason: sum(x["reason"] == reason for x in skipped)
              for reason in ("probed", "checkpoint_ready")}
    print(f"total=180 probed={counts['probed']} checkpoint_ready={counts['checkpoint_ready']} "
          f"vast_jobs={len(jobs)} plan={args.output}")


def train_one(args) -> None:
    if args.mode not in MODES or not 0 <= args.index < 60:
        raise ValueError("invalid Sphere run")
    if args.micro_batch < 1 or 1024 % args.micro_batch:
        raise ValueError("micro-batch must divide 1024")
    ns = scope(args.mode, args.output, args.device)
    experiment, training = ns["ACTIVE_RUNS"][args.index]
    if args.pilot_tokens:
        training = replace(training, name=f"{training.name}_pilot", total_tokens=args.pilot_tokens)
    train_run(ns, experiment, training, args)


def train_run(ns, experiment, training, args, *,
              hypothesis_id="H-R2-05-polar-ladder-capacity",
              dataset="fresh streamed Mess-4 polar Sphere trajectories") -> None:
    """Train one immutable recipe; campaigns supply their own scoped selection."""
    if args.micro_batch < 1 or training.batch_size % args.micro_batch:
        raise ValueError("micro-batch must divide batch size")
    name = run_name(experiment, training)
    args.output.mkdir(parents=True, exist_ok=True)
    checkpoint = args.output / f"{name}.pth"
    metadata_path = checkpoint.with_suffix(".json")
    ready = checkpoint.with_suffix(".ready")
    process = experiment.build_process()
    revision = source_revision()
    configuration_hash = configuration_sha256(experiment, training, process)
    if validate_ready(checkpoint, revision, configuration_hash):
        print(f"already_ready {name}")
        return
    if checkpoint.exists() or metadata_path.exists():
        raise RuntimeError(f"incomplete existing run {name}; inspect before retry")
    model = training.build_model(process)
    random_model = training.build_model(process)
    model.load_state_dict(random_model.state_dict())
    sanity_batch = ns["sample_physics_batch"](
        process, np.random.default_rng(training.seed), 2, exp_cfg=experiment)
    if not np.isfinite(sanity_batch["observable"]).all():
        raise ValueError(f"nonfinite Sphere trajectory for {name}")
    sanity = torch.as_tensor(sanity_batch["tokens"], dtype=torch.long)
    with torch.no_grad():
        logits = random_model(sanity)
        expected = torch.nn.functional.cross_entropy(
            logits[:, :-training.k].reshape(-1, process.n_obs),
            sanity[:, training.k:].reshape(-1))
    assert torch.allclose(random_model.loss(sanity), expected)
    random_checkpoint = args.output / f"{name}_random_init.pt"
    random_digest = save_weights(random_model, random_checkpoint)
    def sample(rng, size):
        batch = ns["sample_physics_batch"](process, rng, size, exp_cfg=experiment)
        if not np.isfinite(batch["observable"]).all() or not np.isfinite(batch["metric"]).all():
            raise ValueError(f"nonfinite Sphere trajectory for {name}")
        return batch["tokens"]

    started = time.time()
    train_config = replace(training.train_config(),
                           checkpoint_at=tuple(range(250_000_000, training.total_tokens, 250_000_000)))
    tokens_per_update = training.batch_size * process.seq_len
    def on_checkpoint(target, snapshot_model):
        actual_tokens = min(training.total_tokens // tokens_per_update * tokens_per_update,
                            (target + tokens_per_update - 1) // tokens_per_update * tokens_per_update)
        # ponytail: weight snapshots omit optimizer state; add it when exact interruption resume is needed.
        path = args.output / f"{name}_progress_{actual_tokens}_tokens.pt"
        snapshot_hash = save_weights(snapshot_model, path)
        sidecar = path.with_suffix(".json")
        sidecar_part = sidecar.with_name(sidecar.name + ".part")
        sidecar_part.write_text(json.dumps({
            "source_revision": revision, "configuration_sha256": configuration_hash,
            "tokens_seen": actual_tokens, "updates": actual_tokens // tokens_per_update,
            "elapsed_seconds": time.time() - started, "requested_tokens": training.total_tokens,
            "acceptance_state": "partial_training_checkpoint",
            "checkpoint_sha256": snapshot_hash, "random_checkpoint_filename": random_checkpoint.name,
            "random_checkpoint_sha256": random_digest,
        }, indent=2) + "\n")
        os.replace(sidecar_part, sidecar)

    report = ns["train"](
        model,
        sample, process.seq_len, train_config, device=args.device,
        micro_batch_size=args.micro_batch, on_checkpoint=on_checkpoint,
    )
    metadata_part = metadata_path.with_suffix(".json.part")
    digest = save_weights(model, checkpoint)
    metadata = {
        "project": "Belief-in-physics", "hypothesis_id": hypothesis_id,
        "experiment_id": name, "dataset": dataset,
        "acceptance_state": "full_training_complete; held-out probes pending",
        "scientific_acceptance": "unmeasured",
        "process": experiment.process_name, "experiment": experiment.metadata(),
        "model": asdict(training.model_config(process)), "training": asdict(training),
        "source_revision": revision, "configuration_sha256": configuration_hash,
        "device": args.device, "torch_version": torch.__version__,
        "python_version": platform.python_version(), "host": platform.node(),
        "gpu_name": torch.cuda.get_device_name(0) if args.device == "cuda" else None,
        "tokens_seen": report["tokens_seen"], "updates": report["steps"],
        "requested_tokens": training.total_tokens, "final_loss": report["final"],
        "loss_history": report["history"],
        "stream_seed": training.seed + training.stream_seed_offset,
        "eval_seed": training.seed + 99_999, "eval_size": training.eval_size,
        "micro_batch_size": args.micro_batch, "elapsed_seconds": time.time() - started,
        "checkpoint_sha256": digest,
        "random_checkpoint_filename": random_checkpoint.name,
        "random_checkpoint_sha256": random_digest,
    }
    metadata_part.write_text(json.dumps(metadata, indent=2) + "\n")
    os.replace(metadata_part, metadata_path)
    ready_part = ready.with_suffix(".ready.part")
    ready_part.write_text(digest + "\n")
    os.replace(ready_part, ready)
    print(f"ready {name} tokens={report['tokens_seen']} seconds={metadata['elapsed_seconds']:.1f}")


def run_batch(args) -> None:
    plan_data = json.loads(args.plan.read_text())
    if plan_data["source_revision"] != source_revision():
        raise ValueError("plan revision differs from checkout; regenerate plan")
    if not 1 <= args.workers <= 12 or args.max_hours <= 0:
        raise ValueError("workers must be 1..12 and max-hours positive")
    entries = plan_data["jobs"] + plan_data["skipped"]
    if len(entries) != 180 or len({entry["name"] for entry in entries}) != 180:
        raise ValueError("plan must contain 180 unique runs")
    scoped = {mode: scope(mode, args.output)["ACTIVE_RUNS"] for mode in MODES}
    for entry in entries:
        if entry["mode"] not in scoped or not 0 <= entry["index"] < 60:
            raise ValueError("invalid planned Sphere run")
        experiment, training = scoped[entry["mode"]][entry["index"]]
        if (entry["name"] != run_name(experiment, training) or
                entry["configuration_sha256"] != configuration_sha256(
                    experiment, training, experiment.build_process())):
            raise ValueError("plan recipe differs from checkout; regenerate plan")
    args.output.mkdir(parents=True, exist_ok=True)
    logs = args.output / "logs"
    logs.mkdir(exist_ok=True)
    jobs = plan_data["jobs"][:args.limit or None]
    active = {}
    deadline = time.monotonic() + args.max_hours * 3600
    failed = False
    def stop_batch(_signum, _frame):
        raise SystemExit(143)
    old_sigterm = signal.signal(signal.SIGTERM, stop_batch)
    try:
        while jobs or active:
            while jobs and len(active) < args.workers and not failed and time.monotonic() < deadline:
                job = jobs.pop(0)
                suffix = "_pilot" if args.pilot_tokens else ""
                ready = args.output / f"{job['name']}{suffix}.ready"
                if ready.exists():
                    checkpoint = args.output / f"{job['name']}{suffix}.pth"
                    validate_ready(checkpoint, source_revision(),
                                   None if args.pilot_tokens else job["configuration_sha256"])
                    continue
                log = open(logs / f"{job['name']}{suffix}.log", "a")
                command = [sys.executable, __file__, "train", "--mode", job["mode"],
                           "--index", str(job["index"]), "--output", str(args.output),
                           "--device", "cuda", "--micro-batch", str(args.micro_batch),
                           "--pilot-tokens", str(args.pilot_tokens)]
                process = subprocess.Popen(command, cwd=ROOT, stdout=log,
                                           stderr=subprocess.STDOUT, start_new_session=True)
                active[process] = (job, log)
                print(f"started {job['name']} pid={process.pid}", flush=True)
            if time.monotonic() >= deadline:
                print("batch deadline reached", flush=True)
                failed = True
                break
            for process, (job, log) in list(active.items()):
                status = process.poll()
                if status is None:
                    continue
                log.close()
                del active[process]
                print(f"finished {job['name']} exit={status}", flush=True)
                if status:
                    failed = True
            if failed:
                break
            if active:
                time.sleep(2)
    finally:
        for process, (_job, log) in active.items():
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            log.close()
        signal.signal(signal.SIGTERM, old_sigterm)
    if failed:
        raise RuntimeError("batch stopped; inspect logs and completed artifacts")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    planning = sub.add_parser("plan")
    planning.add_argument("--completed-dir", type=Path, required=True)
    planning.add_argument("--output", type=Path, required=True)
    worker = sub.add_parser("train")
    worker.add_argument("--mode", choices=MODES, required=True)
    worker.add_argument("--index", type=int, required=True)
    worker.add_argument("--output", type=Path, required=True)
    worker.add_argument("--device", default="cuda")
    worker.add_argument("--micro-batch", type=int, default=64)
    worker.add_argument("--pilot-tokens", type=int, default=0)
    batch = sub.add_parser("batch")
    batch.add_argument("--plan", type=Path, required=True)
    batch.add_argument("--output", type=Path, required=True)
    batch.add_argument("--workers", type=int, default=12)
    batch.add_argument("--micro-batch", type=int, default=64)
    batch.add_argument("--pilot-tokens", type=int, default=0)
    batch.add_argument("--limit", type=int, default=0)
    batch.add_argument("--max-hours", type=float, required=True)
    args = parser.parse_args()
    {"plan": plan, "train": train_one, "batch": run_batch}[args.command](args)


if __name__ == "__main__":
    main()
