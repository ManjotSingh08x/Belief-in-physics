"""Both spherical angles, with the archived polar campaign's unchanged dynamics."""
from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar

import numpy as np

from .sphere_polar import SphereBall as PolarSphereBall


@dataclass(frozen=True)
class SphereAngles(PolarSphereBall):
    # Cover the full polar coordinate range, including randomized releases.
    obs_range: tuple[float, float] = (0.0, np.pi)
    observable_names: ClassVar[tuple[str, ...]] = ("theta", "psi")
    state_names: ClassVar[tuple[str, ...]] = ("theta", "psi", "dtheta", "dpsi")
    periodic_channels: ClassVar[tuple[bool, ...]] = (False, True)
    required_obs_channels: ClassVar[int] = 2

    @property
    def obs_ranges(self) -> tuple[tuple[float, float], ...]:
        return (self.obs_range, (-np.pi, np.pi))

    def observables(self, z: np.ndarray) -> np.ndarray:
        return np.stack([z[..., 0], (z[..., 1] + np.pi) % (2 * np.pi) - np.pi], axis=-1)
