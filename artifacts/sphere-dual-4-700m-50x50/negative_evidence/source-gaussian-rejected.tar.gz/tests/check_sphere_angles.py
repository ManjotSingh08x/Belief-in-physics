"""Run with PYTHONPATH=. python tests/check_sphere_angles.py; no training."""
import hashlib
from pathlib import Path

import numpy as np

from physics.messk import MessDriven
from physics.systems.sphere_angles import SphereAngles
from physics.systems.sphere_polar import SphereBall


def test_joint_angles():
    proc = MessDriven(system=SphereAngles(), obs_bins=(181, 181),
                      dt=.04, integration_dt=.005, delta_v=.12, m=3)
    assert proc.n_obs == 32761 and proc.channel_names == ("theta", "psi")
    with np.testing.assert_raises(ValueError):
        MessDriven(system=SphereAngles())  # Cannot silently use theta alone.
    with np.testing.assert_raises(ValueError):
        proc.discretise([[np.nan, 0]])

    rng = np.random.default_rng(20261005)
    angles = rng.uniform([0, -np.pi], [np.pi, np.pi], (1000, 2))
    tokens = proc.discretise(angles)
    bins = proc.tokens_to_indices(tokens)
    np.testing.assert_array_equal(tokens, bins[:, 0] * 181 + bins[:, 1])
    recovered = proc.undiscretise(tokens)
    assert np.abs(recovered[:, 0] - angles[:, 0]).max() <= np.pi / 360 + 1e-12
    circular_error = (recovered[:, 1] - angles[:, 1] + np.pi) % (2 * np.pi) - np.pi
    assert np.abs(circular_error).max() <= np.pi / 181 + 1e-12
    np.testing.assert_array_equal(proc.discretise(recovered), tokens)
    np.testing.assert_array_equal(proc.discretise(angles + [0, 2 * np.pi]), tokens)
    np.testing.assert_array_equal(proc.discretise([[.6, -np.pi], [.6, np.pi]]),
                                  [proc.discretise([.6, -np.pi])] * 2)
    assert proc.discretise([.6, 0]) != proc.discretise([.6, np.pi / 2])
    seam = proc.tokens_to_indices(proc.discretise([[.6, np.pi - .04], [.6, -np.pi + .04]]))
    assert tuple(seam[:, 1]) == (180, 1)  # Neighbours across circular bin 0.
    all_tokens = np.arange(proc.n_obs)
    np.testing.assert_array_equal(proc.discretise(proc.undiscretise(all_tokens)), all_tokens)

    legacy = MessDriven(system=SphereBall(), dt=.04, integration_dt=.005, delta_v=.12, m=3)
    z = proc.system.initial_state(32) + rng.normal(0, .1, (32, 4))
    new = proc.sample_batch(np.random.default_rng(7), 32, initial_state=z)
    old = legacy.sample_batch(np.random.default_rng(7), 32, initial_state=z)
    assert new["tokens"].shape == (32, 30) and new["observable"].shape == (32, 30, 2)
    assert np.isfinite(new["observable"]).all()
    assert 0 <= new["tokens"].min() <= new["tokens"].max() < proc.n_obs
    np.testing.assert_array_equal(new["letters"], old["letters"])
    np.testing.assert_array_equal(new["metric"], old["metric"])
    np.testing.assert_array_equal(new["observable"][..., 0], old["observable"][..., 0])
    theta = old["observable"][..., 0]
    np.testing.assert_array_equal(old["tokens"], np.clip(np.rint((theta - .05) / 1.2 * 180), 0, 180))
    assert hashlib.sha256(Path("physics/systems/sphere_polar.py").read_bytes()).hexdigest() == (
        "74d08b5e13d9c572eac9dc4c5d1b1943a5c0c94348b765a269c604a6f2fe1787")


if __name__ == "__main__":
    test_joint_angles()
    print("PASS: joint angles, circular seam, all 32761 token round trips, randomized sampling, legacy parity")
