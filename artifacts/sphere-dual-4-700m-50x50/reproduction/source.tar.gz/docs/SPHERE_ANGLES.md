# Joint Sphere angle tokens

The 180-run polar campaign observed only theta. Its 181-token checkpoints and
published heatmaps cannot represent absolute azimuth or demonstrate convergence
of full spatial trajectories. They remain evidence about a partial observation.

Use the same physical dynamics with both angles:

```python
from physics.messk import MessDriven
from physics.systems.sphere_angles import SphereAngles

proc = MessDriven(system=SphereAngles(), obs_bins=(50, 50),
                  dt=0.04, integration_dt=0.005, delta_v=0.12)
tokens = proc.observe(states)  # states[..., :] = theta, psi, dtheta, dpsi
angles = proc.undiscretise(tokens)
```

All angles are radians. Theta covers [0, pi], rather than clipping to the old
empirical [0.05, 1.25] observation band. Azimuth is circular with 50 distinct
bin centers in [-pi, pi); -pi and +pi name the same center. The formulas are:

```
i_theta = clip(rint(theta / pi * 49), 0, 49)
i_psi   = floor(((psi + pi) mod (2*pi)) / (2*pi) * 50 + 0.5) mod 50
token   = i_theta * 50 + i_psi
```

Vocabulary size is 2,500; one token encodes one pair of angle bins, not a mood.
Quantization error is at most 90/49 degrees in theta and 3.6 degrees in azimuth.
The system requires two bin counts so a scalar default fails clearly.
Sampling accepts explicit randomized initial states through the existing
`sample_batch(..., initial_state=...)` argument. Velocities still require inference
from observation history: these are position tokens, not full phase-space tokens.

Build new models with `vocab_size=proc.n_obs`. The old weights are incompatible;
new training, grouped held-out probes, calibration, and randomized-start tests
are required before making claims about learned joint predictions.

The four-model campaign uses native 500-token context, k=10, d128, four layers,
two heads, MLP512, seed0, and 700M requested input tokens per model (699,904,000
actual). Release offsets for theta, dtheta and dpsi are uniform in [-0.1,0.1],
with independent uniform azimuth in [-pi,pi). This replaces an unbounded Gaussian
release rejected after a 4,096-trajectory audit found rare clipping and momentum
drift. The rejected attempt's artifacts remain separate from completed models.

Selection requires bin-changing impulses, four distinct ten-token histories,
no sampled pole/rate contacts, angular-momentum conservation, finer-step
agreement, additional independent seeds, and a 4,096-trajectory stress audit.
These are finite preflight checks, not proof of stability for every possible
HMM sequence or of optimal learned performance. Neutral azimuth also prevents
claiming that contracting polar-angle curves prove full spatial convergence.

Heatmap colors show the native joint-token head and its theta/psi marginals.
Dashed curves show four physical action counterfactual endpoints at t+10,
recomputed from the actual current state. Four-mood linear-probe heatmaps are
separate and labeled as simplex-projected readouts. Neither display forces four
high-probability neural modes.

Check: `PYTHONPATH=. python tests/check_sphere_angles.py`.
