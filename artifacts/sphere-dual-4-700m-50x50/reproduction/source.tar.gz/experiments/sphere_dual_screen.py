"""Bounded 500-token, randomized-start safety/bin screen; never trains a model."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import sys
import time

os.environ["OPENBLAS_NUM_THREADS"] = "1"
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np

from physics.messk import MessDriven, MessKProcess
from physics.systems.sphere import SphereBall as CartesianSphere
from physics.systems.sphere_angles import SphereAngles
from physics.systems.sphere_polar import THETA_MIN, THETA_MAX

SEEDS = (20261005, 20261006, 20261007)
DT = .04
HORIZON = 500


def process(config, integration_dt=.005):
    return MessDriven(system=SphereAngles(gamma=config["gamma"]),
                      chain=MessKProcess(alpha=config["alpha"]), obs_bins=(50, 50),
                      delta_v=config["delta_v"], dt=DT, integration_dt=integration_dt,
                      n_steps=config["n"], m=HORIZON // config["n"])


def starts(system, seed, count):
    rng = np.random.default_rng(seed)
    # Bounded releases avoid rare Gaussian tails reaching numerical pole/rate caps.
    z = system.initial_state(count) + rng.uniform(-.1, .1, (count, 4))
    z[:, 1] = rng.uniform(-np.pi, np.pi, count)
    return z


def simulate(proc, seed, count, deadline):
    z = starts(proc.system, seed, count)
    twin = z.copy()
    twin[:, 0] += 1e-7
    # Compare nearby starts on the same conserved angular-momentum surface.
    # Otherwise a different conserved momentum creates linear azimuthal shear,
    # which a short log-gap fit incorrectly classifies as exponential growth.
    twin[:, 3] *= (np.sin(z[:, 0]) / np.sin(twin[:, 0])) ** 2
    momentum = np.sin(z[:, 0]) ** 2 * z[:, 3]
    momentum_drift = 0.
    letters = proc.chain.sample(np.random.default_rng(seed + 100), count, proc.m)[1]
    states = np.empty((count, HORIZON, 4))
    gaps = np.empty((count, HORIZON))
    fork_starts = []
    bound_hits = 0
    for t in range(HORIZON):
        if time.monotonic() > deadline:
            raise TimeoutError("CPU screen deadline")
        if t % 100 == 0:
            fork_starts.append(z.copy())
        if t % proc.n_steps == 0:
            action = proc.actions[letters[:, t // proc.n_steps]]
            z = proc.system.kick(z, action)
            twin = proc.system.kick(twin, action)
            bound_hits += int(np.sum(np.abs(z[:, 2:]) >= proc.system.rate_max - 1e-10))
        z = proc.flow(z)
        twin = proc.flow(twin)
        states[:, t] = z
        momentum_drift = max(momentum_drift, float(np.max(np.abs(np.sin(z[:, 0]) ** 2 * z[:, 3] - momentum))))
        gaps[:, t] = CartesianSphere.state_gap(proc.system, z, twin)
        bound_hits += int(np.sum((z[:, 0] <= THETA_MIN + 1e-10) |
                                 (z[:, 0] >= THETA_MAX - 1e-10)))
        bound_hits += int(np.sum(np.abs(z[:, 2:]) >= proc.system.rate_max - 1e-10))
    source = np.concatenate(fork_starts)
    branch = proc.system.kick(np.repeat(source, 4, axis=0), np.tile(proc.actions, (len(source), 1)))
    no_kick = source.copy()
    branch_tokens, free_tokens = [], []
    fork_bound_hits = 0
    for _ in range(10):
        branch = proc.flow(branch)
        no_kick = proc.flow(no_kick)
        branch_tokens.append(proc.observe(branch).reshape(len(source), 4))
        free_tokens.append(proc.observe(no_kick))
        fork_bound_hits += int(np.sum((branch[:, 0] <= THETA_MIN + 1e-10) |
                                      (branch[:, 0] >= THETA_MAX - 1e-10)))
        fork_bound_hits += int(np.sum(np.abs(branch[:, 2:]) >= proc.system.rate_max - 1e-10))
    tokens = np.stack(branch_tokens, axis=-1)
    free = np.stack(free_tokens, axis=-1)
    distinct = np.ones(len(source), dtype=bool)
    for a in range(4):
        for b in range(a):
            distinct &= np.any(tokens[:, a] != tokens[:, b], axis=-1)
    changed = np.any(tokens != free[:, None], axis=-1)
    endpoint_distinct = np.all(np.diff(np.sort(tokens[:, :, -1], axis=1), axis=1) > 0, axis=1)
    # Report transient and late finite-time slopes separately; neutral azimuth
    # means theta contraction alone must never count as spatial contraction.
    t_axis = (np.arange(HORIZON) + 1) * DT
    late = t_axis >= 5
    slopes = np.polyfit(t_axis[late], np.log(np.maximum(gaps[:, late].T, 1e-300)), 1)[0]
    return states, {
        "seed": seed, "finite": bool(np.isfinite(states).all() and np.isfinite(branch).all()),
        "physical_bound_hits": bound_hits, "fork_bound_hits": fork_bound_hits,
        "theta_range": [float(states[..., 0].min()), float(states[..., 0].max())],
        "max_abs_rates": np.abs(states[..., 2:]).max(axis=(0, 1)).tolist(),
        "four_distinct_10token_histories": float(distinct.mean()),
        "four_distinct_endpoint_bins": float(endpoint_distinct.mean()),
        "each_action_changes_bins": changed.mean(axis=0).tolist(),
        "late_full_phase_lambda_max": float(slopes.max()),
        "late_full_phase_lambda_mean": float(slopes.mean()),
        "full_phase_initial_gap_mean": float(gaps[:, 0].mean()),
        "full_phase_final_gap_mean": float(gaps[:, -1].mean()),
        "maximum_conserved_momentum_drift": momentum_drift,
        "used_joint_bins": int(len(np.unique(proc.observe(states)))),
        "fork_count": len(source),
    }


def metric_pass(m):
    return (m['finite'] and m['physical_bound_hits'] == m['fork_bound_hits'] == 0
            and m['maximum_conserved_momentum_drift'] < 1e-4 and m['four_distinct_10token_histories'] >= .99
            and min(m['each_action_changes_bins']) >= .99 and m['late_full_phase_lambda_max'] <= .05)


def screen(args):
    if Path('/proc/swaps').exists() and len(Path('/proc/swaps').read_text().splitlines()) > 1:
        raise RuntimeError("screen requires no swap")
    started = time.monotonic()
    deadline = started + args.max_seconds
    damping_grid = ((10, .7), (20, .7)) if args.higher_damping else ((10, .35), (20, .175), (20, .35))
    configs = [{"n": n, "gamma": gamma, "delta_v": delta, "alpha": alpha}
               for n, gamma in damping_grid
               for delta in (.10, .14, .20, .30, .40, .50)
               for alpha in (.70, .85, .95)]
    out = {"hypothesis_id": "H-SPHERE-JOINT-50", "experiment_id": "sphere-dual-four-screen",
           "dataset": "fresh bounded uniform offsets [-.1,.1]; azimuth uniform [-pi,pi)",
           "host": socket.gethostname(), "python": platform.python_version(), "numpy": np.__version__,
           "obs_bins": [50, 50], "vocabulary_size": 2500, "horizon": HORIZON,
           "seeds": list(SEEDS), "trajectories_per_seed": args.trajectories,
           "dt": DT, "integration_dt": .005, "k": 10,
           "source_sha256": {str(p.resolve().relative_to(Path(__file__).resolve().parents[1])):
                               hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in [Path(__file__), Path('physics/messk.py'),
                                         Path('physics/systems/sphere_angles.py'), Path('physics/systems/sphere_polar.py')]},
           "status": "running", "results": [], "selected": [],
           "scientific_acceptance": "physics preflight only; trained performance unknown"}
    out["stability_protocol"] = "full phase-space twin on equal conserved angular momentum; late 5-20s slope; no pole/rate contact; neutral azimuth is not spatial contraction"
    args.output.parent.mkdir(parents=True, exist_ok=True)

    def save():
        out["elapsed_seconds"] = time.monotonic() - started
        tmp = args.output.with_suffix('.tmp')
        tmp.write_text(json.dumps(out, indent=2, allow_nan=False) + '\n')
        tmp.replace(args.output)

    for config in configs:
        proc = process(config)
        rows = [simulate(proc, seed, args.trajectories, deadline)[1] for seed in SEEDS]
        minimum_changed = min(min(row["each_action_changes_bins"]) for row in rows)
        minimum_distinct = min(row["four_distinct_10token_histories"] for row in rows)
        maximum_lambda = max(row["late_full_phase_lambda_max"] for row in rows)
        passed = all(metric_pass(row) for row in rows)
        result = {"config": config, "seed_metrics": rows, "pass": passed,
                  "minimum_each_action_changes_bins": minimum_changed,
                  "minimum_four_distinct_histories": minimum_distinct,
                  "minimum_four_distinct_endpoint_bins": min(row["four_distinct_endpoint_bins"] for row in rows),
                  "maximum_late_full_phase_lambda": maximum_lambda}
        out["results"].append(result)
        save()
        print(json.dumps({"config": config, "pass": passed, "distinct": minimum_distinct,
                          "changed": minimum_changed, "lambda": maximum_lambda}), flush=True)
    candidates = sorted((r for r in out["results"] if r["pass"]), key=lambda r: (
        r["minimum_four_distinct_endpoint_bins"], r["minimum_each_action_changes_bins"],
        r["minimum_four_distinct_histories"], -r["maximum_late_full_phase_lambda"]), reverse=True)
    for candidate_index, row in enumerate(candidates):
        config = row["config"]
        proc = process(config)
        reference = process(config, .0025)
        agreement, error, states_total = [], [], 0
        for seed in SEEDS:
            z, metrics = simulate(proc, seed, args.trajectories, deadline)
            fine, fine_metrics = simulate(reference, seed, args.trajectories, deadline)
            agreement.append(float(np.mean(proc.observe(z) == proc.observe(fine))))
            error.append(float(CartesianSphere.state_gap(proc.system, z, fine).max()))
            states_total += z.shape[0] * z.shape[1]
            if fine_metrics["physical_bound_hits"] or fine_metrics["fork_bound_hits"] or not fine_metrics["finite"]:
                agreement[-1] = 0.
        row["reference"] = {"integration_dt": .0025, "min_joint_token_agreement": min(agreement),
                            "max_full_phase_error": max(error), "states": states_total}
        if min(agreement) >= .999 and max(error) < 1e-3:
            row['stress_seed'] = simulate(proc, 20261200 + candidate_index, 4096, deadline)[1]
            row['stress_seed_pass'] = metric_pass(row['stress_seed'])
            if row['stress_seed_pass']:
                out["selected"].append(row)
        save()
        if len(out["selected"]) == 4:
            break
    out["status"] = "four_selected" if len(out["selected"]) == 4 else "insufficient_safe_settings"
    save()


def validate_selected(args):
    out = json.loads(args.output.read_text())
    out["validation_runtime_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    deadline = time.monotonic() + args.max_seconds
    for row in out["selected"]:
        if row.get("additional_seed_pass") and len(row.get("additional_seeds", [])) == 10:
            continue
        p = process(row["config"])
        if "reference" not in row:
            fine_p = process(row["config"], .0025)
            agreements, errors = [], []
            for seed in SEEDS:
                z, _ = simulate(p, seed, 16, deadline)
                fine, _ = simulate(fine_p, seed, 16, deadline)
                agreements.append(float(np.mean(p.observe(z) == p.observe(fine))))
                errors.append(float(CartesianSphere.state_gap(p.system, z, fine).max()))
            row["reference"] = {"integration_dt": .0025, "min_joint_token_agreement": min(agreements),
                                "max_full_phase_error": max(errors), "states": 24000}
        row["additional_seeds"] = [simulate(p, seed, 32, deadline)[1]
                                   for seed in range(20261100, 20261110)]
        row["additional_seed_pass"] = row["reference"]["min_joint_token_agreement"] >= .999 and row["reference"]["max_full_phase_error"] < 1e-3 and all(metric_pass(m) for m in row["additional_seeds"])
        args.output.write_text(json.dumps(out, indent=2, allow_nan=False) + '\n')
        print(row["config"], "additional_seed_pass", row["additional_seed_pass"], flush=True)
    for index, row in enumerate(out['selected']):
        if 'stress_seed' not in row:
            row['stress_seed'] = simulate(process(row['config']), 20261200 + index, 4096, deadline)[1]
        m = row['stress_seed']
        row['stress_seed_pass'] = metric_pass(m)
        args.output.write_text(json.dumps(out, indent=2, allow_nan=False) + '\n')
        print(row['config'], '4096_trajectory_stress_pass', row['stress_seed_pass'], flush=True)
    out["status"] = "four_selected" if all(r["additional_seed_pass"] and r['stress_seed_pass'] for r in out["selected"]) else "additional_seed_gate_failed"
    args.output.write_text(json.dumps(out, indent=2, allow_nan=False) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--trajectories', type=int, default=16)
    parser.add_argument('--max-seconds', type=int, default=1200)
    parser.add_argument('--validate-selected', action='store_true')
    parser.add_argument('--higher-damping', action='store_true')
    args = parser.parse_args()
    if not 1 <= args.trajectories <= 64 or not 1 <= args.max_seconds <= 3600:
        parser.error('invalid bounded screen size or runtime')
    (validate_selected if args.validate_selected else screen)(args)
