"""Runnable checks for cumulative budget arithmetic and tamper-detecting exports."""
import csv
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from experiments.sphere_dual_control import budget_deadline
from experiments.sphere_dual_analysis_queue import verify


def check():
    receipt = dict(created_at=100., transfer_reserve=.75, prior_rental_reserve=.1, guard_hourly_rate=.2)
    deadline = budget_deadline(receipt)
    assert deadline == 100. + 20.75 * 3600
    assert (deadline - 100.) / 3600 * .2 + .75 + .1 == 5.
    for bad in (dict(prior_rental_reserve=-1), dict(prior_rental_reserve=5), dict(guard_hourly_rate=.21)):
        try:
            budget_deadline(receipt | bad)
        except ValueError:
            pass
        else:
            raise AssertionError('invalid budget accepted')
    with tempfile.TemporaryDirectory() as temp:
        directory = Path(temp) / 'export_fixture'
        directory.mkdir()
        row = dict(alpha=1., validation_r2=.2, test_r2=.1, feature_dim=8, train_rows_per_feature=20.)
        (directory / 'analysis.json').write_text(json.dumps({'probes': [row] * 16}))
        with (directory / 'probes.csv').open('w', newline='') as f:
            writer = csv.DictWriter(f, row.keys()); writer.writeheader(); writer.writerows([row] * 16)
        archive_path = directory.parent / (directory.name + '.zip')
        with zipfile.ZipFile(archive_path, 'w') as archive:
            for file in directory.iterdir():
                archive.write(file, file.name)
        hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in directory.iterdir()}
        (directory / 'EXPORT_VERIFIED.json').write_text(json.dumps({
            'zip_sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(), 'member_sha256': hashes}))
        assert len(verify(directory)['probes']) == 16
        (directory / 'probes.csv').write_text('tampered')
        try:
            verify(directory)
        except AssertionError:
            pass
        else:
            raise AssertionError('tampered export accepted')
    print('cumulative budget, ZIP members and numerical export checks passed')


if __name__ == '__main__':
    check()
