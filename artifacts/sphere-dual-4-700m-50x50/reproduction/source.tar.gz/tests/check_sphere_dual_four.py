"""Validate four real 50x50 recipes and their k=10 losses without training."""
from dataclasses import asdict
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import torch

from experiments.sphere_dual_four import runs
from experiments.sphere_vast_train import configuration_sha256


def check(screen, output):
    torch.set_num_threads(2)
    ns, selected = runs(screen, output.parent)
    assert len(selected) == 4
    evidence = []
    for exp, tr in selected:
        p = exp.build_process()
        assert p.obs_bins == (50, 50) and p.n_obs == 2500 and p.seq_len == 500
        cfg = tr.model_config(p)
        assert (cfg.d_model, cfg.n_layers, cfg.n_heads, cfg.d_mlp, cfg.n_ctx, tr.k) == (128, 4, 2, 512, 500, 10)
        assert tr.total_tokens == 700_000_000 and tr.seed == 0
        b = exp.sample_batch(p, np.random.default_rng(74), 2)
        assert b['observable'].shape == (2, 500, 2)
        assert np.isfinite(b['observable']).all() and 0 <= b['tokens'].min() <= b['tokens'].max() < 2500
        index = p.tokens_to_indices(b['tokens'])
        np.testing.assert_array_equal(index[..., 0] * 50 + index[..., 1], b['tokens'])
        all_tokens = np.arange(2500)
        np.testing.assert_array_equal(p.discretise(p.undiscretise(all_tokens)), all_tokens)
        assert not np.array_equal(b['initial_state'][0], b['initial_state'][1])
        assert exp.initial_state.mode == 'random'
        offset = b['initial_state'][:, [0, 2, 3]] - p.system.initial_state(2)[:, [0, 2, 3]]
        assert (np.abs(offset) <= .1).all()
        assert exp.initial_state.release_distribution == 'uniform coordinate offsets [-.1,.1]'
        model = tr.build_model(p).eval()
        t = torch.as_tensor(b['tokens'], dtype=torch.long)
        with torch.no_grad():
            logits = model(t)
            manual = torch.nn.functional.cross_entropy(logits[:, :-10].reshape(-1, 2500), t[:, 10:].reshape(-1))
            assert torch.isfinite(manual) and torch.allclose(model.loss(t), manual)
        evidence.append({'experiment': exp.metadata(), 'model': asdict(cfg), 'training': asdict(tr),
                         'configuration_sha256': configuration_sha256(exp, tr, p),
                         'untrained_smoke_loss': float(manual), 'optimizer_updates': 0})
    output.write_text(json.dumps({'status': 'passed', 'models': evidence}, indent=2) + '\n')


if __name__ == '__main__':
    check(Path(sys.argv[1]), Path(sys.argv[2]))
