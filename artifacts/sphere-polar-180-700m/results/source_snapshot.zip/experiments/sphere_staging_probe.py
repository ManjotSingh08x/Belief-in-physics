"""Probe one transferred Sphere checkpoint on the CPU staging host."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import resource
import socket
import sys
import zipfile
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "2"

import numpy as np
import torch
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from models.analysis import residual_streams_batched
from experiments.sphere_vast_train import MODES, configuration_sha256, run_name, scope


def ridge_score(X, y, splits) -> dict:
    fit, validation, test = splits
    selected = None
    best = None
    for alpha in (1.0, 10.0, 100.0, 1000.0, 10000.0):
        candidate = make_pipeline(StandardScaler(), Ridge(alpha=alpha, solver="lsqr"))
        candidate.fit(X[fit], y[fit])
        validation_r2 = float(r2_score(y[validation], candidate.predict(X[validation])))
        if best is None or validation_r2 > best["validation_r2"]:
            selected = candidate
            best = {"alpha": alpha, "validation_r2": validation_r2,
                    "feature_dim": int(X.shape[1]),
                    "train_rows_per_feature": float(len(fit) / X.shape[1])}
    best["test_r2"] = float(r2_score(y[test], selected.predict(X[test])))
    return best


def token_features(streams, last):
    ticks = [stream[:, last] for stream in streams]
    return {"single_layer_single_token": ticks[-1],
            "all_block_layers_single_token": np.concatenate(ticks[1:], axis=-1),
            "embedding_and_all_layers_single_token": np.concatenate(ticks, axis=-1)}


def sequence_splits(tokens):
    _, groups = np.unique(tokens, axis=0, return_inverse=True)
    order = np.random.default_rng(29).permutation(len(tokens))
    # Keep identical full token histories together, preserving the original split when all are unique.
    group_order = np.array(list(dict.fromkeys(groups[order])))
    group_parts = np.split(group_order, (int(.6 * len(group_order)), int(.8 * len(group_order))))
    group_sets = [set(part) for part in group_parts]
    return tuple(np.array([index for index in order if groups[index] in part], dtype=np.int64)
                 for part in group_sets)


def self_check():
    streams = [np.full((2, 4, 3), depth, dtype=np.float32) for depth in range(5)]
    features = token_features(streams, np.array([1, 3]))
    assert features["all_block_layers_single_token"].shape == (2, 2, 12)
    assert np.array_equal(features["all_block_layers_single_token"][0, 0], np.repeat([1, 2, 3, 4], 3))
    assert features["embedding_and_all_layers_single_token"].shape == (2, 2, 15)
    rng = np.random.default_rng(29)
    x = rng.normal(size=(200, 4))
    y = x @ rng.normal(size=(4, 2))
    result = ridge_score(x, y, (np.arange(120), np.arange(120, 160), np.arange(160, 200)))
    assert result["test_r2"] > .99
    duplicate_tokens = np.repeat(np.arange(100)[:, None], 2, axis=0)
    parts = sequence_splits(duplicate_tokens)
    observed = [set(duplicate_tokens[part, 0]) for part in parts]
    assert observed[0].isdisjoint(observed[1]) and observed[0].isdisjoint(observed[2])
    unique_tokens = np.arange(100)[:, None]
    assert all(np.array_equal(a, b) for a, b in zip(sequence_splits(unique_tokens),
               np.split(np.random.default_rng(29).permutation(100), (60, 80))))
    print("one-token layer ordering and held-out ridge ok")


def probe(checkpoint: Path, n_trajectories: int) -> None:
    metadata_path = checkpoint.with_suffix(".json")
    csv_path = checkpoint.with_suffix(".csv")
    zip_path = checkpoint.with_suffix(".zip")
    if csv_path.exists() or zip_path.exists():
        if csv_path.exists() and zip_path.exists():
            print(f"already_probed {checkpoint.stem}")
            return
        raise RuntimeError(f"partial probe output for {checkpoint.stem}")
    metadata = json.loads(metadata_path.read_text())
    digest = hashlib.sha256(checkpoint.read_bytes()).hexdigest()
    if metadata.get("checkpoint_sha256") and metadata["checkpoint_sha256"] != digest:
        raise ValueError("checkpoint hash differs from training metadata")
    matched = None
    for mode in MODES:
        notebook = scope(mode, checkpoint.parent)
        for experiment, training in notebook["ACTIVE_RUNS"]:
            if run_name(experiment, training) == checkpoint.stem:
                matched = experiment, training, notebook
                break
        if matched:
            break
    if not matched:
        raise ValueError(f"checkpoint not in Sphere manifest: {checkpoint.stem}")
    experiment, training, notebook = matched
    process = experiment.build_process()
    expected_experiment = json.loads(json.dumps(experiment.metadata()))
    expected_training = json.loads(json.dumps(asdict(training)))
    expected_tokens = (training.total_tokens // (training.batch_size * process.seq_len)
                       * training.batch_size * process.seq_len)
    if (process.dt != 0.04 or experiment.physics.integration_dt != 0.005 or process.n_obs != 181 or
            training.d_model != 128 or training.n_layers != 4 or training.n_heads != 2 or
            metadata.get("experiment") != expected_experiment or
            metadata.get("training") != expected_training or
            metadata.get("source_revision") != os.environ.get(
                "BELIEF_SOURCE_REVISION", metadata.get("source_revision")) or
            metadata.get("configuration_sha256") != configuration_sha256(experiment, training, process) or
            training.total_tokens != 700_000_000 or metadata["tokens_seen"] != expected_tokens):
        raise ValueError("checkpoint configuration does not match the production sweep")
    torch.set_num_threads(2)
    trained = training.build_model(process)
    trained.load_state_dict(torch.load(checkpoint, map_location="cpu", weights_only=True))
    random_model = training.build_model(process)
    random_checkpoint = checkpoint.with_name(checkpoint.stem + "_random_init.pt")
    if (metadata.get("random_checkpoint_filename") != random_checkpoint.name or
            hashlib.sha256(random_checkpoint.read_bytes()).hexdigest() != metadata["random_checkpoint_sha256"]):
        raise ValueError("random checkpoint does not match training metadata")
    random_model.load_state_dict(torch.load(random_checkpoint, map_location="cpu", weights_only=True))
    batch = notebook["sample_physics_batch"](
        process, np.random.default_rng(20260929), n_trajectories,
        exp_cfg=experiment,
    )
    last = np.arange(experiment.n - 1, process.seq_len, experiment.n)
    belief = batch["beliefs"][:, last]
    metric = batch["metric"][:, last]
    targets = {"physics": metric.reshape(-1, metric.shape[-1]),
               "belief": belief.reshape(-1, belief.shape[-1])}
    seq_splits = sequence_splits(batch["tokens"])
    splits = tuple((part[:, None] * process.m + np.arange(process.m)).reshape(-1) for part in seq_splits)
    assert set(seq_splits[0]).isdisjoint(seq_splits[2])
    rows = []
    for tag, model in (("trained", trained), ("random_init", random_model)):
        streams = residual_streams_batched(model.eval(), batch["tokens"], "cpu", batch_size=16)
        modes = token_features(streams, last)
        del streams
        for mode, features in modes.items():
            X = features.reshape(n_trajectories * process.m, -1).astype(np.float32)
            for target, y in targets.items():
                score = ridge_score(X, y, splits)
                rows.append({"experiment": experiment.name, "system": experiment.process_name,
                             "training": training.name, "seed": training.seed, "k_lookahead": training.k,
                             "d_model": training.d_model, "n_layers": training.n_layers,
                             "model_type": tag, "mode": mode, "target": target, **score})
        del modes, features, X
    if len(rows) != 12 or not all(np.isfinite(row["validation_r2"]) and np.isfinite(row["test_r2"])
                                   for row in rows):
        raise ValueError("missing or nonfinite probe scores")
    csv_temp = csv_path.with_suffix(".csv.part")
    with csv_temp.open("w", newline="") as f:
        writer = csv.DictWriter(f, rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)
    metadata["probes"] = rows
    metadata["probe_trajectories"] = n_trajectories
    metadata["probe_host"] = "staging-entity"
    metadata["acceptance_state"] = "full_training_and_held_out_probe_complete"
    metadata["scientific_acceptance"] = "one training seed measured against matched random; aggregate seeds before acceptance"
    metadata["probe_hostname"] = socket.gethostname()
    metadata["probe_protocol"] = {"evaluation_seed": 20260929, "split_seed": 29,
                                  "split_counts": [len(part) for part in seq_splits],
                                  "unique_full_token_sequences": len(np.unique(batch["tokens"], axis=0)),
                                  "duplicate_histories_kept_in_same_split": True,
                                  "features": "last token per HMM tick; no token concatenation",
                                  "targets": "four raw belief probabilities and two tangent velocities",
                                  "target_variance": {key: np.var(value, axis=0).tolist() for key, value in targets.items()},
                                  "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    metadata_temp = metadata_path.with_suffix(".json.part")
    metadata_temp.write_text(json.dumps(metadata, indent=2) + "\n")
    archive_temp = zip_path.with_suffix(".zip.part")
    with zipfile.ZipFile(archive_temp, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in (checkpoint, random_checkpoint, metadata_temp, csv_temp):
            archive.write(path, arcname=path.name.replace(".part", ""))
    with zipfile.ZipFile(archive_temp) as archive:
        assert sorted(archive.namelist()) == sorted(
            (checkpoint.name, random_checkpoint.name, metadata_path.name, csv_path.name))
    os.replace(metadata_temp, metadata_path)
    os.replace(csv_temp, csv_path)
    os.replace(archive_temp, zip_path)
    print(f"probed {checkpoint.stem} rows={len(rows)}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("checkpoint", type=Path, nargs="?")
    parser.add_argument("--self-check", action="store_true")
    parser.add_argument("--trajectories", type=int, default=2048)
    args = parser.parse_args()
    if args.trajectories < 256:
        raise ValueError("at least 256 trajectories are needed for held-out probes")
    resource.setrlimit(resource.RLIMIT_AS, (12 * 1024**3, 12 * 1024**3))
    if args.self_check:
        self_check()
    elif args.checkpoint is None:
        parser.error("checkpoint is required")
    else:
        probe(args.checkpoint, args.trajectories)


if __name__ == "__main__":
    main()
