"""Next-observation-token training, with no auxiliary objective.

The generator is unlimited and every optimisation step sees a fresh batch, so
there is no finite training corpus to memorise. The model receives only the 181
observation bins and is never shown the chain letter, physical action, mood, or
belief used to produce them.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import torch
from tqdm.auto import tqdm

from .transformer import TinyTransformer


@dataclass(frozen=True)
class TrainConfig:
    total_tokens: int = 40_000_000
    batch_size: int = 128
    learning_rate: float = 1e-3
    weight_decay: float = 0.0
    warmup_frac: float = 0.02
    grad_clip: float | None = 1.0
    seed: int = 0
    log_every: int = 100
    stream_seed_offset: int = 1
    eval_size: int = 256
    checkpoint_at: tuple[int, ...] = ()  # token counts to hand to `on_checkpoint`


def checkpoint_paths(directory, name: str, tag: str = ""):
    """`(tokens_seen, path)` for every checkpoint of one run, sorted.

    `tag` separates runs of the same system that differ in seed or in kick
    magnitude, which all live in one directory.
    """
    from pathlib import Path

    prefix = f"{name}{tag}_"
    return sorted(
        (int(p.stem[len(prefix):]), p)
        for p in Path(directory).glob(f"{prefix}*.pt")
        if p.stem[len(prefix):].isdigit()
    )


def pick_device() -> str:
    forced = __import__("os").environ.get("DEVICE")
    if forced:
        return forced
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def train(
    model: TinyTransformer,
    sampler,
    seq_len: int,
    config: TrainConfig,
    device: str | None = None,
    on_checkpoint=None,
    micro_batch_size: int | None = None,
) -> dict:
    """Stream batches from `sampler(rng, n) -> tokens` and fit next-token loss.

    `sampler` rather than a process object keeps the loop indifferent to which
    physical system generated the observation tokens.

    `on_checkpoint(tokens_seen, model)` fires the first time the token count
    passes each entry of `config.checkpoint_at`. The LR schedule is defined over
    `total_tokens`, so a checkpoint is a snapshot part-way along *this* run, not
    a model that was trained to that budget and annealed.
    """
    device = device or pick_device()
    model = model.to(device)
    if micro_batch_size is not None and not 1 <= micro_batch_size <= config.batch_size:
        raise ValueError("micro_batch_size must be between 1 and batch_size")

    steps = max(1, config.total_tokens // (config.batch_size * seq_len))
    warmup = max(1, int(steps * config.warmup_frac))

    # Plain Adam, matching the belief-geometry literature. AdamW's decoupled
    # decay is a different optimiser, and Adam carrying a non-zero
    # `weight_decay` is a third thing again (coupled L2), so the default is 0.
    optimiser = torch.optim.Adam(
        model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay
    )

    def lr_at(step: int) -> float:
        if step < warmup:
            return step / warmup
        progress = (step - warmup) / max(1, steps - warmup)
        return 0.5 * (1.0 + math.cos(math.pi * progress))

    schedule = torch.optim.lr_scheduler.LambdaLR(optimiser, lr_at)

    stream = np.random.default_rng(config.seed + config.stream_seed_offset)
    eval_tokens = None
    if config.eval_size:
        eval_rng = np.random.default_rng(config.seed + 99_999)
        eval_tokens = torch.as_tensor(sampler(eval_rng, config.eval_size), dtype=torch.long, device=device)

    history: list[dict] = []
    tokens_per_step = config.batch_size * seq_len
    pending = sorted(config.checkpoint_at)
    saved: list[int] = []

    model.train()
    for step in tqdm(range(steps), desc="train", dynamic_ncols=True):
        seen = step * tokens_per_step
        while pending and seen >= pending[0]:
            target = pending.pop(0)
            if on_checkpoint is not None:
                model.eval()
                on_checkpoint(target, model)
                model.train()
            saved.append(target)

        optimiser.zero_grad(set_to_none=True)
        train_loss = torch.zeros((), device=device)
        remaining = config.batch_size
        while remaining:
            size = min(remaining, micro_batch_size or config.batch_size)
            tokens = torch.as_tensor(sampler(stream, size), dtype=torch.long, device=device)
            loss = model.loss(tokens)
            weight = size / config.batch_size
            (loss * weight).backward()
            train_loss += loss.detach() * weight
            remaining -= size
        if config.grad_clip is not None:
            torch.nn.utils.clip_grad_norm_(model.parameters(), config.grad_clip)
        optimiser.step()
        schedule.step()

        if step % config.log_every == 0 or step == steps - 1:
            model.eval()
            with torch.no_grad():
                eval_loss = float(model.loss(eval_tokens)) if eval_tokens is not None else None
            model.train()
            row = {"step": step, "train_loss": float(train_loss)}
            if eval_loss is not None:
                row["eval_loss"] = eval_loss
            history.append(row)
            print_every = max(config.log_every, max(1, steps // 200))
            if step % print_every == 0 or step == steps - 1:
                lr_curr = schedule.get_last_lr()[0]
                print(
                    f"train [{step:5d}/{steps} ({step / steps:5.1%})] "
                    f"loss: {float(train_loss):.4f} | eval_loss: {eval_loss} | lr: {lr_curr:.2e}",
                    flush=True,
                )

    model.eval()
    total_seen = steps * tokens_per_step
    for target in pending:
        if target <= total_seen:
            if on_checkpoint is not None:
                on_checkpoint(target, model)
            saved.append(target)

    return {
        "history": history,
        "checkpoints": saved,
        "steps": steps,
        "seq_len": seq_len,
        "tokens_seen": steps * config.batch_size * seq_len,
        "device": device,
        "final": history[-1] if history else None,
    }
